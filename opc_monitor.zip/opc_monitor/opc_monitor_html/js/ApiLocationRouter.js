var EndLocation='http://127.0.0.1/api/';


//not yet
var CommonLocation=EndLocation+'Common/';


//not yet
var RealTimeLogLocation='ws://127.0.0.1/api/RealTimeLog/RealTimeLog';
